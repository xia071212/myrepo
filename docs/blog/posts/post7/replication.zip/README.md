# Blog 7: AI exposure and employment outlook

This focused package reproduces the 722-occupation chart and descriptive comparisons.
Install requirements.txt, then run code/build_interactive_sample.py and code/check_projection_patterns.py and code/regress_projections.py in that order. Paths resolve relative to the scripts. The first produces results/interactive_sample.html, a self-contained Plotly chart, and the processed projection samples. The second writes results/projection_patterns/.

Sources: BLS official 2024–2034 archive https://www.bls.gov/emp/projections-archive/2024-34.zip (occupation.xlsx, Table 1.2); Anthropic job_exposure.csv and task_penetration.csv from https://www.anthropic.com/research/labor-market-impacts; O*NET 30.0 task descriptions https://www.onetcenter.org/database.html. The task tables are retained inputs from the task-matching stage; see the main README included below for that stage's methods. Employment is converted from thousands to people. Use detailed Line item rows, match SOC, and retain task coverage >=95%.

Group exposure/breadth use 2024 employment weights; group growth uses summed employment levels. Detailed growth uses the published BLS percentages. Detailed dots have equal sizes. Group bubbles encode sample employment. Coverage is relative to official major-group employment. Search isolates one occupation; clearing restores the group. The chart uses Chinese labels; the article's embedded copy translates the same chart into English.

The bin comparisons use only shared exposure intervals and pooled employment weights across intervals; they are descriptive, not causal or significance tests. Output CSVs report sample coverage. Predictions are not realized employment or AI replacement rates.
