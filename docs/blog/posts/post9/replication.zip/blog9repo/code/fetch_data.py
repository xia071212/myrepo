"""Download the classroom Yahoo Finance data source; keep a frozen snapshot."""
from pathlib import Path
import json
import yfinance as yf
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/raw/yahoo_prices.csv.gz"
if OUT.exists():
    raise SystemExit("Frozen snapshot already exists; remove it explicitly to refresh.")
tickers = json.loads((ROOT / "data/universe.json").read_text()) + ["SPY"]
raw = yf.download(tickers, start="2022-01-01", end="2026-11-14", auto_adjust=False,
                  actions=True, progress=False, threads=4, group_by="ticker")
frames = []
for symbol in tickers:
    d = raw[symbol].copy().dropna(subset=["Close"])
    d["symbol"] = symbol
    d.index.name = "date"
    frames.append(d.reset_index())
import pandas as pd
out = pd.concat(frames, ignore_index=True)
assert set(out.symbol) == set(tickers)
OUT.parent.mkdir(parents=True,exist_ok=True)
out.to_csv(OUT,index=False,compression="gzip")
print(out.groupby("symbol").date.agg(["min","max","count"]).to_string())
