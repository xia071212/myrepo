"""Setup -> clean/engineer -> analyze/save -> plot. Run from any directory."""
from pathlib import Path
import argparse, json, itertools, hashlib, shutil
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import brentq
from xgboost import XGBRegressor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# 1. Setup: fixed decisions are documented in Blog9_plan.md.
ROOT = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(); parser.add_argument('--output',type=Path,default=ROOT/'results'); args=parser.parse_args()
OUT=args.output; OUT.mkdir(parents=True,exist_ok=True)
SEED=123; CUT=pd.Timestamp('2024-01-01'); CASH=100000.; N=10
universe=json.loads((ROOT/'data/universe.json').read_text())
original=['Open','High','Low','Close','Volume','adjusted','return','spy_ret','mom_1m','mom_3m','mom_6m','vol_1m','ret_5d','excess_ret']
modified=['momentum_21','momentum_63','momentum_126','reversal_5','volatility_21','relative_21','relative_63','excess_lag1']

# 2. Read, validate, and construct features without mixing stock histories.
raw=pd.read_csv(ROOT/'data/raw/yahoo_prices.csv.gz',parse_dates=['date']).sort_values(['symbol','date'])
assert not raw.duplicated(['symbol','date']).any()
assert (raw[['Close','Adj Close']]>0).all().all()
calendar=pd.DatetimeIndex(sorted(raw.loc[raw.symbol.eq('SPY'),'date'].unique()))
assert calendar.max()<=pd.Timestamp('2026-11-13')
spy=raw[raw.symbol.eq('SPY')].set_index('date')['Adj Close'].reindex(calendar)
spyret=spy.pct_change(fill_method=None)
frames=[]; coverage=[]
for symbol in universe:
    d=raw[raw.symbol.eq(symbol)].set_index('date').reindex(calendar).copy()
    coverage.append({'symbol':symbol,'observed':int(d.Close.notna().sum()),'missing':int(d.Close.isna().sum()),'zero_volume':int(d.Volume.eq(0).sum())})
    # Abort rather than silently drop stocks or fill prices after seeing outcomes.
    assert d[['Open','High','Low','Close','Volume','Adj Close']].notna().all().all(), symbol
    p=d['Adj Close']; r=p.pct_change(fill_method=None)
    d['adjusted']=p; d['return']=r; d['spy_ret']=spyret
    for lag,name in [(21,'mom_1m'),(63,'mom_3m'),(126,'mom_6m')]:
        d[name]=p.shift(lag)/p.shift(1)-1 # preserve classroom inverse convention
    d['vol_1m']=r.shift(1).rolling(22).std(ddof=1)
    d['ret_5d']=p.shift(5)/p.shift(1)-1
    d['excess_ret']=r-spyret
    for lag in [21,63,126]:
        d[f'momentum_{lag}']=p.shift(1)/p.shift(lag+1)-1
    d['reversal_5']=p.shift(1)/p.shift(6)-1
    d['volatility_21']=r.shift(1).rolling(21).std(ddof=1)
    for lag in [21,63]:
        d[f'relative_{lag}']=d[f'momentum_{lag}']-(spy.shift(1)/spy.shift(lag+1)-1)
    d['excess_lag1']=(r-spyret).shift(1)
    d['target']=p.shift(-21)/p.shift(-1)-1
    d['entry_date']=pd.Series(calendar,index=calendar).shift(-1)
    d['exit_date']=pd.Series(calendar,index=calendar).shift(-21)
    d['symbol']=symbol; d.index.name='date'
    frames.append(d.reset_index())
pd.DataFrame(coverage).to_csv(OUT/'data_coverage.csv',index=False)
panel=pd.concat(frames,ignore_index=True).dropna(subset=original+modified+['target','entry_date','exit_date'])
assert np.isfinite(panel[original+modified+['target']].to_numpy()).all()
panel=panel.sort_values(['date','symbol'])
train=panel[panel.exit_date<CUT].copy()
assert train.exit_date.max()<CUT
start=calendar.searchsorted(CUT)
signal_dates=calendar[np.arange(start,len(calendar)-21,20)]
test=panel[panel.date.isin(signal_dates)].copy()
assert test.groupby('date').size().eq(len(universe)).all()
assert len(test)==len(signal_dates)*len(universe)

# 3a. Classroom paired comparison (unchanged original observed final balances).
classroom=pd.read_excel(ROOT/'data/classroom_results.xlsx')
rets=classroom[['portfolio1','portfolio2']]/CASH-1
diff=rets.portfolio2-rets.portfolio1
ci=stats.t.interval(.95,len(diff)-1,loc=diff.mean(),scale=stats.sem(diff))
class_stats={'n':len(diff),'mean1':rets.portfolio1.mean(),'mean2':rets.portfolio2.mean(),'mean_difference':diff.mean(),'ci_low':ci[0],'ci_high':ci[1],'p_two_sided':stats.ttest_rel(rets.portfolio2,rets.portfolio1).pvalue,'wins':int((diff>0).sum())}
(OUT/'classroom_summary.json').write_text(json.dumps(class_stats,indent=2))
rets.assign(difference=diff,team=np.arange(1,len(diff)+1)).to_csv(OUT/'classroom_returns.csv',index=False)

# 3b. Hyperparameter selection uses only two purged 2023 validation windows.
def make_model(params,kind):
    common=dict(objective='reg:squarederror',tree_method='hist',random_state=SEED,n_jobs=4,gamma=0)
    if kind=='original':
        return XGBRegressor(**common,n_estimators=300,max_depth=5,learning_rate=.05,min_child_weight=10,subsample=1,colsample_bytree=1,reg_lambda=1,reg_alpha=0)
    return XGBRegressor(**common,**params,min_child_weight=20,subsample=.8,colsample_bytree=.8,reg_lambda=10,reg_alpha=0)
candidates=[dict(max_depth=d,learning_rate=l,n_estimators=n) for d,l,n in itertools.product([2,3],[.03,.05],[150,300])]
folds=[(pd.Timestamp('2023-01-01'),pd.Timestamp('2023-07-01')),(pd.Timestamp('2023-07-01'),CUT)]
scores=[]
for cid,params in enumerate(candidates):
    errors=[]
    for f,(a,b) in enumerate(folds):
        tr=panel[panel.exit_date<a]
        va=panel[(panel.date>=a)&(panel.exit_date<b)]
        # Evaluate every 20 trading days, mirroring the deployment horizon.
        dates=calendar[(calendar>=a)&(calendar<b)][::20]
        va=va[va.date.isin(dates)]
        assert tr.exit_date.max()<va.date.min() and va.exit_date.max()<CUT
        model=make_model(params,'modified').fit(tr[modified],tr.target)
        mse=float(np.mean((model.predict(va[modified])-va.target)**2));errors.append(mse)
        scores.append({'candidate':cid,'fold':f+1,**params,'mse':mse,'train_n':len(tr),'validation_n':len(va),'train_last_label':str(tr.exit_date.max().date()),'validation_start':str(va.date.min().date()),'validation_last_label':str(va.exit_date.max().date())})
    print('candidate',cid,'validation RMSE',np.sqrt(np.mean(errors)),flush=True)
score=pd.DataFrame(scores);score.to_csv(OUT/'validation_scores.csv',index=False)
best=int(score.groupby('candidate').mse.mean().idxmin());selected=candidates[best]
# Persist the decision before evaluating the held-out test set.
(OUT/'selected_model.json').write_text(json.dumps({'candidate':best,**selected,'selection':'minimum equal-fold validation MSE','seed':SEED},indent=2))
pred=test[['date','symbol','target','entry_date','exit_date']].copy()
for name,cols,kind in [('Original XGBoost',original,'original'),('Modified XGBoost',modified,'modified')]:
    model=make_model(selected,kind).fit(train[cols],train.target)
    pred[name]=model.predict(test[cols])
    model.save_model(OUT/('original_model.json' if kind=='original' else 'modified_model.json'))
pred['Historical mean']=test.symbol.map(train.groupby('symbol').target.mean())
models=['Original XGBoost','Modified XGBoost','Historical mean']
pred.to_csv(OUT/'test_predictions.csv',index=False)
metrics=[];rankrows=[]
for name in models:
    ics=[]
    for dt,g in pred.groupby('date'):
        ic=stats.spearmanr(g[name],g.target).statistic;ics.append(ic)
        rankrows.append({'date':dt,'model':name,'spearman':ic})
    metrics.append({'model':name,'rmse':float(np.sqrt(np.mean((pred[name]-pred.target)**2))),'mean_spearman':float(np.mean(ics)),'n_predictions':len(pred),'n_signals':len(signal_dates)})
pd.DataFrame(metrics).to_csv(OUT/'prediction_metrics.csv',index=False)
pd.DataFrame(rankrows).to_csv(OUT/'rank_correlations.csv',index=False)

# 3c. Self-financing, fractional-unit ledger: post-fee assets solve a scalar equation.
prices=raw.pivot(index='date',columns='symbol',values='Adj Close').reindex(calendar)[universe]
selections={}
for name in models:
    selections[name]={dt:g.sort_values([name,'symbol'],ascending=[False,True]).head(N).symbol.tolist() for dt,g in pred.groupby('date')}
entry_dates=[calendar[calendar.get_loc(dt)+1] for dt in signal_dates]
last_exit=calendar[calendar.get_loc(signal_dates[-1])+21]
assert all((calendar.get_loc(b)-calendar.get_loc(a))==20 for a,b in zip(entry_dates,entry_dates[1:]))
ledger_rows=[];daily_rows=[];period_rows=[];performance=[]
for name in models:
  for cost in [0.,.001,.002]:
    units=np.zeros(len(universe)); cash=CASH; daily=[{'date':signal_dates[0],'equity':CASH}];turnovers=[];totalfees=0.
    for k,dt in enumerate(signal_dates):
        entry=entry_dates[k];end=calendar[calendar.get_loc(dt)+21]
        px=prices.loc[entry].to_numpy();before=units*px;wealth=before.sum()+cash
        w=np.array([.1 if s in selections[name][dt] else 0 for s in universe]);assert np.isclose(w.sum(),1)
        # New invested wealth z plus cost on traded dollars equals pretrade wealth.
        z=brentq(lambda z:z+cost*np.abs(w*z-before).sum()-wealth,0,wealth) if cost else wealth
        traded=np.abs(w*z-before).sum();fee=cost*traded
        assert abs(z+fee-wealth)<1e-7
        units=w*z/px;cash=0.;turnovers.append(traded/wealth);totalfees+=fee
        if daily[-1]['date']==entry:daily[-1]['equity']=z
        else:daily.append({'date':entry,'equity':z})
        ledger_rows.append({'model':name,'cost_rate':cost,'date':entry,'event':'rebalance','pretrade_equity':wealth,'posttrade_equity':z,'traded_dollars':traded,'cost_dollars':fee,'turnover':traded/wealth,'holdings':','.join(selections[name][dt])})
        path=prices.loc[(prices.index>entry)&(prices.index<=end)].to_numpy()@units
        for date,value in zip(prices.loc[(prices.index>entry)&(prices.index<=end)].index,path):daily.append({'date':date,'equity':value})
        endvalue=path[-1]
        actual=endvalue/z-1
        expected=pred[(pred.date==dt)&pred.symbol.isin(selections[name][dt])].target.mean()
        assert abs(actual-expected)<1e-10
        period_rows.append({'model':name,'cost_rate':cost,'signal_date':dt,'entry_date':entry,'exit_date':end,'holding_return':actual,'selected_mean_target':expected})
    final_before=daily[-1]['equity'];fee=final_before*cost;totalfees+=fee;daily[-1]['equity']-=fee
    ledger_rows.append({'model':name,'cost_rate':cost,'date':last_exit,'event':'liquidate','pretrade_equity':final_before,'posttrade_equity':final_before-fee,'traded_dollars':final_before,'cost_dollars':fee,'turnover':1.,'holdings':''})
    daily_df=pd.DataFrame(daily).drop_duplicates('date',keep='last').sort_values('date')
    assert daily_df.date.is_unique and (daily_df.equity>0).all()
    dd=1-daily_df.equity/daily_df.equity.cummax()
    performance.append({'model':name,'cost_rate':cost,'cumulative_return':daily_df.equity.iloc[-1]/CASH-1,'max_drawdown':dd.max(),'total_fees_dollars':totalfees,'mean_rebalance_turnover':np.mean(turnovers[1:]),'final_equity':daily_df.equity.iloc[-1]})
    daily_df['model']=name;daily_df['cost_rate']=cost;daily_rows.append(daily_df)
perf=pd.DataFrame(performance);perf.to_csv(OUT/'investment_metrics.csv',index=False)
for name,g in perf.groupby('model'):
    assert np.all(np.diff(g.sort_values('cost_rate').final_equity)<0)
pd.DataFrame(ledger_rows).to_csv(OUT/'trade_ledger.csv',index=False)
pd.concat(daily_rows).to_csv(OUT/'daily_equity.csv',index=False)
pd.DataFrame(period_rows).to_csv(OUT/'holding_period_checks.csv',index=False)
meta={'stocks':len(universe),'data_start':str(calendar.min().date()),'data_end':str(calendar.max().date()),'train_n':len(train),'train_first_signal':str(train.date.min().date()),'train_last_label':str(train.exit_date.max().date()),'first_signal':str(signal_dates[0].date()),'first_trade':str(entry_dates[0].date()),'last_exit':str(last_exit.date()),'signals':len(signal_dates),'selected_parameters':selected,'source_sha256':hashlib.sha256((ROOT/'data/raw/yahoo_prices.csv.gz').read_bytes()).hexdigest(),'checks':'positive complete prices; common samples; purged training/validation; 20-session trades; self-financing; ledger equals held-out targets; monotonic cost sensitivity'}
(OUT/'run_summary.json').write_text(json.dumps(meta,indent=2))

# Summarize selected-stock outcomes separately from whole-universe forecasts.
holding_summary = pd.DataFrame(period_rows)
holding_summary = holding_summary[holding_summary.cost_rate.eq(0)]
selection_rows = []
for name, g in holding_summary.groupby('model'):
    gross = perf[(perf.model == name) & perf.cost_rate.eq(0)].iloc[0]
    net = perf[(perf.model == name) & perf.cost_rate.eq(.001)].iloc[0]
    compounded = float(np.prod(1 + g.holding_return) - 1)
    assert abs(compounded - gross.cumulative_return) < 1e-10
    selection_rows.append({'model': name,
        'mean_selected_return': g.holding_return.mean(),
        'geometric_holding_return': np.expm1(np.log1p(g.holding_return).mean()),
        'compounded_gross_return': compounded,
        'net_return': net.cumulative_return,
        'cost_drag_percentage_points': 100 * (gross.cumulative_return - net.cumulative_return)})
pd.DataFrame(selection_rows).to_csv(OUT/'selection_diagnostics.csv', index=False)

# 4. Save publication figures and tables directly from the calculated results.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','figure.facecolor':'white','savefig.facecolor':'white'})
colors={'Original XGBoost':'#3D6684','Modified XGBoost':'#A65F3F','Historical mean':'#73845B'}
fig,(ax,bx)=plt.subplots(2,1,figsize=(9,5.7),gridspec_kw={'height_ratios':[3.5,1]},layout='constrained')
order=np.argsort(diff.to_numpy());vals=diff.to_numpy()[order]*100
ax.bar(np.arange(45),vals,color=np.where(vals>0,'#73845B','#A65F3F'),width=.78)
ax.axhline(0,color='#444',lw=.8);ax.set(xlabel='Teams ordered by the paired return difference',ylabel='Portfolio 2 − Portfolio 1 (pp)',title='Return Differences Between Portfolio 2 and Portfolio 1');ax.set_xticks([])
bx.errorbar(diff.mean()*100,0,xerr=[[100*(diff.mean()-ci[0])],[100*(ci[1]-diff.mean())]],fmt='o',color='#3D6684',capsize=6,lw=2)
bx.axvline(0,color='#777',ls=':',lw=1);bx.set(yticks=[],xlabel='Mean paired difference and conventional 95% t interval (pp)',xlim=(-1,5));bx.text(diff.mean()*100,.16,f'{diff.mean()*100:.2f} pp',ha='center');bx.set_ylim(-.3,.35)
fig.savefig(OUT/'classroom_difference.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5.4),layout='constrained')
all_daily=pd.concat(daily_rows)
for name in models:
    d=all_daily[(all_daily.model==name)&all_daily.cost_rate.eq(.001)]
    ax.plot(d.date,d.equity/CASH,label=name,color=colors[name],lw=2)
ax.set(title='Cumulative Portfolio Performance After Transaction Costs',ylabel='Growth of $1, after assumed transaction costs',xlabel='');ax.legend(frameon=False,loc='upper left');ax.grid(axis='y',alpha=.18)
fig.savefig(OUT/'portfolio_growth.png',dpi=180);plt.close(fig)
# Markdown tables become Quarto include files; no hand-copied results.
lines=['| Forecast | RMSE (pp) ↓ | Mean rank correlation ↑ |','|:--|--:|--:|']
for r in metrics:lines.append(f"| {r['model']} | {100*r['rmse']:.2f} | {r['mean_spearman']:.3f} |")
(OUT/'prediction_table.qmd').write_text('\n'.join(lines)+'\n')
lines=['| Strategy | Gross return | Net return | Maximum drawdown | Trading per rebalance¹ |','|:--|--:|--:|--:|--:|']
for name in models:
    net=perf[(perf.model==name)&perf.cost_rate.eq(.001)].iloc[0];gross=perf[(perf.model==name)&perf.cost_rate.eq(0)].iloc[0]
    lines.append(f"| {name} | {gross.cumulative_return:.1%} | {net.cumulative_return:.1%} | {net.max_drawdown:.1%} | {net.mean_rebalance_turnover:.1%} |")
(OUT/'investment_table.qmd').write_text('\n'.join(lines)+'\n\n¹ Purchases plus sales divided by pretrade wealth; excludes initial entry and final liquidation. Both are included in returns.\n')
print(json.dumps(meta,indent=2));print(pd.DataFrame(metrics).to_string(index=False));print(perf.to_string(index=False))
